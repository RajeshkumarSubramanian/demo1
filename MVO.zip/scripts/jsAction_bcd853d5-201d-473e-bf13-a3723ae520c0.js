﻿var lock = new java.util.concurrent.locks.ReentrantLock();
var myVar = context.variableManager.getValue("DeviceID.col_0");
if (myVar==null) {
        context.fail("Variable 'myVar' not found");
}
var date = context.variableManager.getValue("CurrentDate");
if (date==null) 
{
 context.fail("Variable 'CurrentDate' not found");
}

function writeFile(text) 
	{
	lock.lock();

var writer = new java.io.FileWriter("d:\\log.txt",true);
	writer.write(date+";"+text);       
	writer.write("\r\n");
	writer.close();
	lock.unlock();
	}
writeFile(myVar+";");