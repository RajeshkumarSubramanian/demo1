﻿var itmtn = context.variableManager.getValue("TradeIn.MTN");

if (itmtn==null) {
       logger.errorl("InstantTradeIn - Variable 'mtn' not found");
}
else{
    logger.error("InstantTradeIn - Login failed for MTN: "+itmtn);    
}