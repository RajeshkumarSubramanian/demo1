﻿// Javascript skeleton.
// Edit and adapt to your needs.
// The documentation of the NeoLoad Javascript API
// is available in the appendix of the documentation.

// Get variable value from VariableManager
var aalmtn = context.variableManager.getValue("AAL.MTN");

if (aalmtn==null) {
       logger.errorl("AAL - Variable 'mtn' not found");
}
else{
    logger.error("AAL - OrderID not returned for MTN: "+aalmtn);    
}