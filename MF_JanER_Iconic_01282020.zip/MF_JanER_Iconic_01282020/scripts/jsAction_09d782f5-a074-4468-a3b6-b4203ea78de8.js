﻿var bmtn = context.variableManager.getValue("Buyout.MTN");

if (bmtn==null) {
       logger.errorl("EUPDP - Variable 'mtn' not found");
}
else{
    logger.error("EUPDP - MTN Not In WhiteList: "+bmtn);    
}