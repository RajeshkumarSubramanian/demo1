﻿var tmtn = context.variableManager.getValue("TradeIn.MTN");

if (tmtn==null) {
       logger.errorl("TradeIn - Variable 'mtn' not found");
}
else{
    logger.error("TradeIn - No Eligible Lines retruned for MTN: "+tmtn);    
}