﻿var bmtn = context.variableManager.getValue("Buyout.MTN");

if (bmtn==null) {
       logger.errorl("EUPDP - Variable 'mtn' not found");
}
else{
    logger.error("EUPDP - No eligible line to updgrade for MTN: "+bmtn);    
}