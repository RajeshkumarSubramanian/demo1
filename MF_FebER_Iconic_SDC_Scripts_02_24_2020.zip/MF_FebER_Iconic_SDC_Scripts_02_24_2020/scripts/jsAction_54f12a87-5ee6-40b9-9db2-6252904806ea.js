﻿// Javascript skeleton.
// Edit and adapt to your needs.
// The documentation of the NeoLoad Javascript API
// is available in the appendix of the documentation.

// Get variable value from VariableManager
var xmtn = context.variableManager.getValue("XUP.MTN");
if (myVar==null) {
        logger.error("EUPX variable 'xmtn' not found");
}
else{
    logger.error("EUPX- No eligible line for upgrade for MTN:"+xmtn);
}