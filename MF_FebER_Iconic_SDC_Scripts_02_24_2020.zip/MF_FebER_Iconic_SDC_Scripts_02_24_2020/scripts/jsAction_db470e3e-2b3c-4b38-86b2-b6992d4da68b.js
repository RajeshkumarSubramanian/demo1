﻿// Javascript skeleton.
// Edit and adapt to your needs.
// The documentation of the NeoLoad Javascript API
// is available in the appendix of the documentation.

// Get variable value from VariableManager
var xmtn = context.variableManager.getValue("XUP.MTN");
if (xmtn==null) {
       logger.error("XUP- Variable 'mtn' 'not found");
}

else
{
    logger.error("XUP- Login failed for : "+xmtn);
    }