﻿// Javascript skeleton.
// Edit and adapt to your needs.
// The documentation of the NeoLoad Javascript API
// is available in the appendix of the documentation.

// Get variable value from VariableManager
var aalmtn = context.variableManager.getValue("Buyout.MTN");

if (aalmtn==null) {
       logger.errorl("Buyout - Variable 'mtn' not found");
}
else{
    logger.error("Buyout - OrderID not returned for MTN: "+aalmtn);    
}