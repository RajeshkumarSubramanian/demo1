﻿var bmtn = context.variableManager.getValue("AAL.MTN");

if (bmtn==null) {
       logger.errorl("AAL - Variable 'mtn' not found");
}
else{
    logger.error("AAL - MTN Not In WhiteList: "+bmtn);    
}